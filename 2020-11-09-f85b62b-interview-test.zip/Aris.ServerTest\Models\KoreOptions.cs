﻿using System;

namespace Aris.ServerTest.Models
{
    public class KoreOptions
    {
        public Uri BaseUrl { get; set; }

        public string Brand { get; set; }

        public string Locale { get; set; }

        public string PlayMode { get; set; }
    }
}
