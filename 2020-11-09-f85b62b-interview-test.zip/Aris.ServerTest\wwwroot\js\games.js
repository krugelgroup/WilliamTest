﻿
$('#category-filter').on('change', function () {

    window.location.href = '?catFilter=' + $('#category-filter').val();

});

